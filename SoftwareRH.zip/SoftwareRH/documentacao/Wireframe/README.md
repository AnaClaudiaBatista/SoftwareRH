# [ucs-projeto-tematico-ll]

- Site para Edição: https://www.mockflow.com/

## Map
<img src="https://github.com/FernandoCelmer/ucs-projeto-tematico-ll/blob/master/Documenta%C3%A7%C3%A3o/Wireframe/Software%20RH%20-%20Map.png?raw=true">

## Tela Inicial
<img src="https://github.com/FernandoCelmer/ucs-projeto-tematico-ll/blob/master/Documenta%C3%A7%C3%A3o/Wireframe/Software%20RH%20-%20Pagina%20Inicial.png?raw=true">
<img src="https://github.com/FernandoCelmer/ucs-projeto-tematico-ll/blob/master/Documenta%C3%A7%C3%A3o/Wireframe/Software%20RH%20-%20Pagina%20Inicial%20-%20Menu%20Cadastros.png?raw=true">

## Cadastro de Usuário
<img src="https://github.com/FernandoCelmer/ucs-projeto-tematico-ll/blob/master/Documenta%C3%A7%C3%A3o/Wireframe/Software%20RH%20-%20Cadastro%20de%20Usu%C3%A1rios%20-%2001.png?raw=true">
<img src="https://github.com/FernandoCelmer/ucs-projeto-tematico-ll/blob/master/Documenta%C3%A7%C3%A3o/Wireframe/Software%20RH%20-%20Cadastro%20de%20Usu%C3%A1rios%20-%2002.png?raw=true">
<img src="https://github.com/FernandoCelmer/ucs-projeto-tematico-ll/blob/master/Documenta%C3%A7%C3%A3o/Wireframe/Software%20RH%20-%20Cadastro%20de%20Usu%C3%A1rios%20-%2003.png?raw=true">

## Registro de Ponto
