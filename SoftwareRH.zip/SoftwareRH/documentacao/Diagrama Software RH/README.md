# [ucs-projeto-tematico-ll]

## Diagrama de Classes
- BaseUsuario
- UsuarioCategoria
- LocalCidade
- LocalEstado
- Financeiro
- FinanceiroCategoria
- FinanceiroFluxo
- Departamento
- BaseBeneficios
- Beneficios
- Empresa
- Logs

### Digrama de Classes - Análise
- Banco de Horas
- Lançamento de Férias
- Atestados
- Recibos

___
<img src="https://github.com/FernandoCelmer/ucs-projeto-tematico-ll/blob/master/Documenta%C3%A7%C3%A3o/Diagrama%20Software%20RH/Software%20RH.png">
